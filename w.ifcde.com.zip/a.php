<?php

  
  $aa=[1,2,3,4];
  $count=count($aa);

  foreach ($aa as $key => $value) {
  	 
  	  '$a_'.$key=$value;
  	//  echo '$a_'.$key .'=>'.$value .'<br/>';
  	 // echo  '$a_'.$key;
  }

  $a='ss';
  $$a='33';

  echo $a;
  echo $$a;
  
?>