<?php


 $mem=new memcached('192.168.163.129',11211);



?>